package GeneratorPML;

public class Interface_PML {
}
