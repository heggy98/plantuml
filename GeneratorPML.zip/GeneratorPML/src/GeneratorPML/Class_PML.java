package GeneratorPML;

import java.util.ArrayList;

public class Class_PML {
    public String Code;
    public ArrayList<String> Access;
    public ArrayList<Atribute_PML> Atributes;
    public ArrayList<Method_PML> Methods;
}
