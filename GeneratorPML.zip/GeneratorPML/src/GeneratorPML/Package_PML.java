package GeneratorPML;

public class Package_PML extends Object_PML {
    public String PackageName;
    public String PackageCode;

    public Package_PML(String packageName) {
        PackageName = packageName;
    }
}
