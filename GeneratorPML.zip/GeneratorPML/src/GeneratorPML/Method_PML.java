package GeneratorPML;

import java.util.ArrayList;

public class Method_PML {
    public ArrayList<String> Parameters;
    public ArrayList<String> Access;
}
